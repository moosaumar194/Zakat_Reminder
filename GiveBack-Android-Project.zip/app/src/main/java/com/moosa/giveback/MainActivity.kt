package com.moosa.giveback

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import java.util.Locale

private val Bg = Color(0xFF101512)
private val Panel = Color(0xFF1A241E)
private val Accent = Color(0xFF9BE2B0)
private val Muted = Color(0xFFAAB8AE)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val prefs = getSharedPreferences("giveback", Context.MODE_PRIVATE)
        setContent {
            GiveBackTheme {
                GiveBackScreen(
                    initialAmount = prefs.getString("amount", "") ?: "",
                    initialPercent = prefs.getString("percent", "5") ?: "5",
                    initialCurrency = prefs.getString("currency", "PKR") ?: "PKR",
                    initialFrequency = prefs.getString("frequency", "Weekly") ?: "Weekly",
                    initialTime = prefs.getString("time", "09:00") ?: "09:00",
                    onSave = { amount, percent, currency, frequency, time ->
                        prefs.edit().putString("amount", amount)
                            .putString("percent", percent).putString("currency", currency)
                            .putString("frequency", frequency).putString("time", time).apply()
                        scheduleReminder(frequency, time)
                    },
                    onCancel = { cancelReminder() }
                )
            }
        }
    }

    private fun scheduleReminder(frequency: String, time: String) {
        val parts = time.split(":")
        val hour = parts.getOrNull(0)?.toIntOrNull() ?: 9
        val minute = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val interval = when (frequency) {
            "Daily" -> AlarmManager.INTERVAL_DAY
            "Monthly" -> AlarmManager.INTERVAL_DAY * 30L
            else -> AlarmManager.INTERVAL_DAY * 7L
        }
        val intent = Intent(this, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            this, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, interval, pending)
    }

    private fun cancelReminder() {
        val pending = PendingIntent.getBroadcast(
            this, 1001, Intent(this, ReminderReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }
}

@Composable
private fun GiveBackTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, onPrimary = Color(0xFF102016),
            background = Bg, surface = Panel, onSurface = Color(0xFFEAF2EC),
            onBackground = Color(0xFFEAF2EC), secondary = Muted
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GiveBackScreen(
    initialAmount: String,
    initialPercent: String,
    initialCurrency: String,
    initialFrequency: String,
    initialTime: String,
    onSave: (String, String, String, String, String) -> Unit,
    onCancel: () -> Unit
) {
    var amount by remember { mutableStateOf(initialAmount) }
    var percent by remember { mutableStateOf(initialPercent) }
    var currency by remember { mutableStateOf(initialCurrency) }
    var frequency by remember { mutableStateOf(initialFrequency) }
    var time by remember { mutableStateOf(initialTime) }
    var saved by remember { mutableStateOf(false) }

    val donation = (amount.toDoubleOrNull() ?: 0.0) * (percent.toDoubleOrNull() ?: 0.0) / 100.0
    val valid = (amount.toDoubleOrNull() ?: -1.0) >= 0 &&
        (percent.toDoubleOrNull() ?: -1.0) in 0.0..100.0 && currency.isNotBlank()

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(shape = RoundedCornerShape(15.dp), color = Panel) {
                    Icon(Icons.Rounded.Favorite, null, tint = Accent, modifier = Modifier.padding(12.dp).size(25.dp))
                }
                Column {
                    Text("GiveBack", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Make generosity a habit", color = Muted, fontSize = 13.sp)
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("YOUR GIVING PLAN", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text("A little, consistently,
can make a difference.", fontSize = 27.sp, fontWeight = FontWeight.SemiBold, lineHeight = 33.sp)
                Text("Set aside a percentage of your income or pocket money.", color = Muted, fontSize = 14.sp)
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Donation calculator", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    OutlinedTextField(
                        value = amount, onValueChange = { amount = it; saved = false },
                        label = { Text("Income / pocket money amount") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors()
                    )
                    OutlinedTextField(
                        value = percent, onValueChange = { percent = it; saved = false },
                        label = { Text("Percentage to donate (%)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors()
                    )
                    OutlinedTextField(
                        value = currency, onValueChange = { currency = it.uppercase(Locale.getDefault()); saved = false },
                        label = { Text("Currency (e.g. PKR, USD)") },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors()
                    )
                    HorizontalDivider(color = Color(0xFF344239))
                    Text("YOUR PLANNED DONATION", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                    Text(
                        "$currency ${String.format(Locale.getDefault(), "%.2f", donation)}",
                        color = Accent, fontSize = 29.sp, fontWeight = FontWeight.Bold
                    )
                    Text("Based on ${percent.ifBlank { "0" }}% of your entered amount", color = Muted, fontSize = 12.sp)
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Rounded.NotificationsActive, null, tint = Accent)
                        Text("Reminder schedule", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    }
                    Text("Remind me", color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Daily", "Weekly", "Monthly").forEach { option ->
                            FilterChip(
                                selected = frequency == option,
                                onClick = { frequency = option; saved = false },
                                label = { Text(option) }
                            )
                        }
                    }
                    var showTimePicker by remember { mutableStateOf(false) }
                    OutlinedButton(onClick = { showTimePicker = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Reminder time: $time")
                    }
                    if (showTimePicker) {
                        val parts = time.split(":")
                        val pickerState = rememberTimePickerState(
                            initialHour = parts.getOrNull(0)?.toIntOrNull() ?: 9,
                            initialMinute = parts.getOrNull(1)?.toIntOrNull() ?: 0,
                            is24Hour = true
                        )
                        AlertDialog(
                            onDismissRequest = { showTimePicker = false },
                            title = { Text("Choose reminder time") },
                            text = { TimePicker(state = pickerState) },
                            confirmButton = {
                                TextButton(onClick = {
                                    time = "%02d:%02d".format(pickerState.hour, pickerState.minute)
                                    saved = false
                                    showTimePicker = false
                                }) { Text("Set time") }
                            },
                            dismissButton = {
                                TextButton(onClick = { showTimePicker = false }) { Text("Cancel") }
                            }
                        )
                    }
                    Text("Reminder notifications are approximate and depend on Android battery settings.", color = Muted, fontSize = 11.sp)
                }
            }

            Button(
                onClick = { onSave(amount, percent, currency, frequency, time); saved = true },
                enabled = valid,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Save my giving plan", fontWeight = FontWeight.Bold) }

            OutlinedButton(onClick = { onCancel(); saved = false }, modifier = Modifier.fillMaxWidth()) {
                Text("Turn off reminders")
            }
            if (saved) Text("Your plan is saved and reminders are scheduled.", color = Accent, fontSize = 13.sp)
            Text("GiveBack stores your plan on this device. It does not transfer money or make donations.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF526157),
    focusedLabelColor = Accent, cursorColor = Accent
)
