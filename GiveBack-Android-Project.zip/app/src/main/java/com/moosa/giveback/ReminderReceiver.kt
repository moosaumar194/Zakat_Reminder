package com.moosa.giveback

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("giveback", Context.MODE_PRIVATE)
        val percent = prefs.getString("percent", "5") ?: "5"
        val amount = prefs.getString("amount", "0") ?: "0"
        val currency = prefs.getString("currency", "PKR") ?: "PKR"
        val donation = runCatching {
            amount.toDouble() * percent.toDouble() / 100.0
        }.getOrDefault(0.0)

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "giveback_reminders"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Donation reminders", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val message = if (donation > 0) {
            "Your planned donation is $currency ${"%.2f".format(donation)} ($percent% of $currency $amount)."
        } else {
            "Take a moment to set aside your planned donation."
        }
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("GiveBack reminder")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setAutoCancel(true)
            .build()
        if (Build.VERSION.SDK_INT < 33 ||
            context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            NotificationManagerCompat.from(context).notify(1001, notification)
        }
    }
}
