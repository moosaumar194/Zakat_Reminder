# GiveBack — Android app

A simple, dark-themed donation-planning app. Set an income or pocket-money amount, choose a percentage, calculate the donation amount, and schedule local reminders.

## Open and build
1. Install Android Studio (Hedgehog or newer).
2. Open this folder as a project.
3. Let Gradle sync.
4. Connect an Android phone or start an emulator (Android 8.0+).
5. Press **Run**.

## Features
- Percentage-based donation calculator.
- PKR by default; currency label is editable.
- Daily, weekly, or monthly reminder schedule.
- Choose a reminder time.
- Local notification reminders; no account or internet required.

## Notes
- The first reminder is scheduled for the next selected time; repeating intervals are daily, 7 days, or approximately 30 days.
- Android 13+ asks for notification permission.
- Android battery optimization can delay inexact reminders.
- This app only reminds and calculates. It does not collect money or send donations.
